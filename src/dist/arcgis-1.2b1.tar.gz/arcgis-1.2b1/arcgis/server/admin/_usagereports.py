"""
This resource is a collection of all the usage reports created within
your site. The Create Usage Report operation lets you define a new
usage report.
"""
from __future__ import absolute_import
from __future__ import print_function
import json
import six
from .._common import BaseServer

########################################################################
class UsageReports(BaseServer):
    """
    This resource is a collection of all the usage reports created within
    your site. The Create Usage Report operation lets you define a new
    usage report.
    """
    _con = None
    _json_dict = None
    _url = None
    _json = None
    _metrics = None
    _reports = None
    #----------------------------------------------------------------------
    def __init__(self, url,
                 connection,
                 initialize=False):
        """Constructor"""
        super(UsageReports, self).__init__(url, connection)
        if url.lower().endswith('/usagereports'):
            self._url = url
        else:
            self._url = url + "/usagereports"
        self._con = connection
        if initialize:
            self.init(connection)
    #----------------------------------------------------------------------
    @property
    def metrics(self):
        """gets the metrics values"""
        if self._metrics is None:
            self.init()
        return self._metrics
    #----------------------------------------------------------------------
    @property
    def reports(self):
        """returns a list of reports on the server"""
        if self._metrics is None:
            self.init()
        self._reports = []
        if isinstance(self._metrics, list):
            for r in self._metrics:
                url = self._url + "/%s" % six.moves.urllib.parse.quote(r['reportname'])
                self._reports.append(UsageReport(url=url,
                                                 connection=self._con))
                del url
        return self._reports
    #----------------------------------------------------------------------
    @property
    def usage_settings(self):
        """
        The usage reports settings are applied to the entire site. A GET
        request returns the current usage reports settings. When usage
        reports are enabled, service usage statistics are collected and
        persisted to a statistics database. When usage reports are
        disabled, the statistics are not collected. The interval
        parameter defines the duration (in minutes) during which the usage
        statistics are sampled or aggregated (in-memory) before being
        written out to the statistics database. Database entries are
        deleted after the interval specified in the max_history parameter (
        in days), unless the max_history parameter is 0, for which the
        statistics are persisted forever.
        """
        params = {
            "f" : "json"
        }
        url = self._url + "/settings"
        return self._con.get(path=url,
                             params=params)
    #----------------------------------------------------------------------
    def edit_settings(self,
                      interval,
                      enabled=True,
                      max_history=0):
        """
        The usage reports settings are applied to the entire site. A POST
        request updates the usage reports settings.

        Inputs:
           interval - Defines the duration (in minutes) for which
             the usage statistics are aggregated or sampled, in-memory,
             before being written out to the statistics database.
           enabled - default True - Can be true or false. When usage
             reports are enabled, service usage statistics are collected
             and persisted to a statistics database. When usage reports are
             disabled, the statistics are not collected.
           max_history - default 0 - Represents the number of days after
             which usage statistics are deleted after the statistics
             database. If the max_history parameter is set to 0, the
             statistics are persisted forever.
        """
        params = {
            "f" : "json",
            "maxHistory" : max_history,
            "enabled" : enabled,
            "samplingInterval" : interval
        }
        url = self._url + "/settings/edit"
        return self._con.post(path=url,
                              postdata=params)
    #----------------------------------------------------------------------
    def create_usage_report(self,
                            reportname,
                            queries,
                            metadata=None,
                            since="LAST_DAY",
                            from_value=None,
                            to_value=None,
                            aggregation_interval=None):
        """
        Creates a new usage report. A usage report is created by submitting
        a JSON representation of the usage report to this operation.

        Inputs:
           reportname - the unique name of the report
           since - the time duration of the report. The supported values
              are: LAST_DAY, LAST_WEEK, LAST_MONTH, LAST_YEAR, CUSTOM
              LAST_DAY represents a time range spanning the previous 24
                 hours.
              LAST_WEEK represents a time range spanning the previous 7
                 days.
              LAST_MONTH represents a time range spanning the previous 30
                 days.
              LAST_YEAR represents a time range spanning the previous 365
                 days.
              CUSTOM represents a time range that is specified using the
                 from and to parameters.
           from_value - optional value - The timestamp (milliseconds since
              UNIX epoch, namely January 1, 1970, 00:00:00 GMT) for the
              beginning period of the report. Only valid when since is
              CUSTOM
           to_value - optional value - The timestamp (milliseconds since
              UNIX epoch, namely January 1, 1970, 00:00:00 GMT) for the
              ending period of the report.Only valid when since is
              CUSTOM.
           aggregation_interval - Optional. Aggregation interval in minutes.
              Server metrics are aggregated and returned for time slices
              aggregated using the specified aggregation interval. The time
              range for the report, specified using the since parameter
              (and from and to when since is CUSTOM) is split into multiple
              slices, each covering an aggregation interval. Server metrics
              are then aggregated for each time slice and returned as data
              points in the report data.
              When the aggregation_interval is not specified, the following
              defaults are used:
                 LAST_DAY: 30 minutes
                 LAST_WEEK: 4 hours
                 LAST_MONTH: 24 hours
                 LAST_YEAR: 1 week
                 CUSTOM: 30 minutes up to 1 day, 4 hours up to 1 week, 1
                 day up to 30 days, and 1 week for longer periods.
             If the interval specified in Usage Reports Settings is
             more than the aggregationInterval, the interval is
             used instead.
           queries - A list of queries for which to generate the report.
              You need to specify the list as an array of JSON objects
              representing the queries. Each query specifies the list of
              metrics to be queries for a given set of resourceURIs.
              The queries parameter has the following sub-parameters:
                 resourceURIs - Comma separated list of resource URIs for
                 which to report metrics. Specifies services or folders
                 for which to gather metrics.
                    The resourceURI is formatted as below:
                       services/ - Entire Site
                       services/Folder/  - Folder within a Site. Reports
                         metrics aggregated across all services within that
                         Folder and Sub-Folders.
                       services/Folder/ServiceName.ServiceType - Service in
                         a specified folder, for example:
                         services/Map_bv_999.MapServer.
                       services/ServiceName.ServiceType - Service in the
                         root folder, for example: Map_bv_999.MapServer.
                 metrics - Comma separated list of metrics to be reported.
                   Supported metrics are:
                    RequestCount - the number of requests received
                    RequestsFailed - the number of requests that failed
                    RequestsTimedOut - the number of requests that timed out
                    RequestMaxResponseTime - the maximum response time
                    RequestAvgResponseTime - the average response time
                    ServiceActiveInstances - the maximum number of active
                      (running) service instances sampled at 1 minute
                      intervals, for a specified service
           metadata - Can be any JSON Object. Typically used for storing
              presentation tier data for the usage report, such as report
              title, colors, line-styles, etc. Also used to denote
              visibility in ArcGIS Server Manager for reports created with
              the Administrator Directory. To make any report created in
              the Administrator Directory visible to Manager, include
              "managerReport":true in the metadata JSON object. When this
              value is not set (default), reports are not visible in
              Manager. This behavior can be extended to any client that
              wants to interact with the Administrator Directory. Any
              user-created value will need to be processed by the client.

        Example:
        >>> queryObj = [{
           "resourceURIs": ["services/Map_bv_999.MapServer"],
           "metrics": ["RequestCount"]
        }]
        >>> obj.createReport(
           reportname="SampleReport",
           queries=queryObj,
           metadata="This could be any String or JSON Object.",
           since="LAST_DAY"
        )
        """
        """
        {
  "reportname": "Max response times for the last 7 days",
  "since": "LAST_WEEK",
  "queries": [{
    "resourceURIs": ["services/"],
    "metrics": ["RequestMaxResponseTime"]
  }],
  "metadata": {
    "temp": false,
    "title": "Max response times for the last 7 days",
    "managerReport": true,
    "styles": {"services/": {"color": "#382DF5"}}
  }
}
        """
        url = self._url + "/add"
        temp = False
        params = {

            "reportname" : reportname,
            "since" : since,
        }
        if  not metadata:
            params['metadata'] = {
                "temp" : temp,
                "title" : reportname,
                "managerReport" : False,

            }
        else:
            params['metadata'] = metadata
        if isinstance(queries, dict):
            params["queries"] = [queries]
        elif isinstance(queries, list):
            params["queries"] = queries
        if aggregation_interval:
            params['aggregationInterval'] = aggregation_interval
        if since.lower() == "custom":
            params['to'] = to_value
            params['from'] = from_value
        p = {"f" : "json",'usagereport' : params}
        res = self._con.post(path=url,
                             postdata=p)
        #  Refresh the metrics object
        self.init()
        for report in self.reports:
            if report.reportname.lower() == reportname.lower():
                return report
        return res
    #----------------------------------------------------------------------
    def quick_report(self,
                     since="LAST_WEEK",
                     queries="services/",
                     metrics="RequestsFailed"):
        """
        The operation quick_report generates an on the fly usage report for
        a service, services, or folder.

        :Parameters:
           since - the time duration of the report. The supported values
              are: LAST_DAY, LAST_WEEK, LAST_MONTH, LAST_YEAR, CUSTOM
              LAST_DAY represents a time range spanning the previous 24
                 hours.
              LAST_WEEK represents a time range spanning the previous 7
                 days.
              LAST_MONTH represents a time range spanning the previous 30
                 days.
              LAST_YEAR represents a time range spanning the previous 365
                 days.
              CUSTOM represents a time range that is specified using the
                 from and to parameters.
           queries - A list of queries for which to generate the report.
              You need to specify the list as an array of JSON objects
              representing the queries. Each query specifies the list of
              metrics to be queries for a given set of resourceURIs.
              The queries parameter has the following sub-parameters:
                 resourceURIs - Comma separated list of resource URIs for
                 which to report metrics. Specifies services or folders
                 for which to gather metrics.
                    The resourceURI is formatted as below:
                       services/ - Entire Site
                       services/Folder/  - Folder within a Site. Reports
                         metrics aggregated across all services within that
                         Folder and Sub-Folders.
                       services/Folder/ServiceName.ServiceType - Service in
                         a specified folder, for example:
                         services/Map_bv_999.MapServer.
                       services/ServiceName.ServiceType - Service in the
                         root folder, for example: Map_bv_999.MapServer.
           metrics - Comma separated list of metrics to be reported.
                   Supported metrics are:
                    RequestCount - the number of requests received
                    RequestsFailed - the number of requests that failed
                    RequestsTimedOut - the number of requests that timed out
                    RequestMaxResponseTime - the maximum response time
                    RequestAvgResponseTime - the average response time
                    ServiceActiveInstances - the maximum number of active
                    (running) service instances sampled at 1 minute
                    intervals, for a specified service
         :Output:
          Python dictionary of data on a successful query.
        """
        from uuid import uuid4
        queries = {
            "resourceURIs": queries.split(','),
            "metrics" : metrics.split(',')
        }
        reportname = uuid4().hex
        metadata = {
                "temp" : True,
                "title" : reportname,
                "managerReport" : False,

            }
        res = self.create_usage_report(reportname=reportname,
                                       queries=queries,
                                       since=since,
                                       metadata=metadata)
        if isinstance(res, UsageReport):
            data = res.query()
            res.delete()
            return data
        return res
########################################################################
class UsageReport(BaseServer):
    """
    A Usage Report is used to obtain ArcGIS Server usage data for specified
    resources during a given time period. It specifies the parameters for
    obtaining server usage data, time range (since from and to parameters),
    aggregation interval, and queries (which specify the metrics to be
    gathered for a collection of server resources, such as folders and
    services).
    """
    _con = None
    _url = None
    _json = None
    _reportname = None
    _since = None
    _from = None
    _to = None
    _aggregationInterval = None
    _queries = None
    _metadata = None
    #----------------------------------------------------------------------
    def __init__(self, url, connection,
                 initialize=False):
        """Constructor"""
        super(UsageReport, self).__init__(url, connection)
        self._con = connection
        self._url = url
        if initialize:
            self.init()
    #----------------------------------------------------------------------
    def edit(self):
        """
        Edits the usage report. To edit a usage report, you need to submit
        the complete JSON representation of the usage report which
        includes updates to the usage report properties. The name of the
        report cannot be changed when editing the usage report.

        Values are changed in the class, to edit a property like
        metrics, pass in a new value.  Changed values to not take until the
        edit() is called.

        Inputs:
           None
        """

        usagereport_dict = {
            "reportname": self._reportname,
            "queries": self._queries,
            "since": self._since,
            "metadata": self._metadata,
            "to" : self._to,
            "from" : self._from,
            "aggregationInterval" : self._aggregationInterval
        }
        params = {
            "f" : "json",
            "usagereport" : json.dumps(usagereport_dict)
        }
        url = self._url + "/edit"
        return self._con.post(path=url,
                              postdata=params)
    #----------------------------------------------------------------------
    def delete(self):
        """deletes the current report"""
        url = self._url + "/delete"
        params = {
            "f" : "json",
        }
        return self._con.post(path=url,
                              postdata=params)
    #----------------------------------------------------------------------
    def query(self, query_filter=None):
        """
        Retrieves server usage data for the report. This operation
        aggregates and filters server usage statistics for the entire
        ArcGIS Server site. The report data is aggregated in a time slice,
        which is obtained by dividing up the time duration by the default
        (or specified) aggregationInterval parameter in the report. Each
        time slice is represented by a timestamp, which represents the
        ending period of that time slice.
        In the JSON response, the queried data is returned for each metric-
        resource URI combination in a query. In the report-data section,
        the queried data is represented as an array of numerical values. A
        response of null indicates that data is not available or requests
        were not logged for that metric in the corresponding time-slice.

        Inputs:
           query_filter - The report data can be filtered by the machine
             where the data is generated. The filter accepts a comma
             separated list of machine names; * represents all machines.

             Examples:
               # filters for the specified machines
               {"machines": ["WIN-85VQ4T2LR5N", "WIN-239486728937"]}
               # no filtering; all machines are accepted
               {"machines": "*"}
        """
        if query_filter is None:
            query_filter = {"machines": "*"}
        params = {
            "f" : "json",
            "filter" : query_filter,
            "filterType" : 'json'
        }
        url = self._url + "/data"
        return self._con.get(path=url, params=params)
