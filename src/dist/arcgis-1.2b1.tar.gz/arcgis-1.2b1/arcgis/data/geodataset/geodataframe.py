"""
Spatial DataFrame Object developed off of the Panda's Dataframe object
"""
from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
import warnings

import arcgis
from six import string_types, integer_types
import pandas as pd
from pandas import DataFrame, Series, Index
import numpy
from arcgis.gis import GIS
from arcgis.data.geodataset.base import BaseSpatialPandas
from arcgis.data.geodataset.geoseries import GeoSeries
from six import PY3
from six import string_types
from arcgis.geometry import types
GEO_COLUMN_DEFAULT = "SHAPE"
GEOM_TYPES = (types.Point, types.MultiPoint,
              types.Polygon,types.Geometry,
              types.Polyline,
              types.BaseGeometry)
try:
    import arcpy
    from arcpy import Geometry
    HASARCPY = True
    GEOM_TYPES = [arcpy.Point, arcpy.Polygon,
                  arcpy.Geometry, arcpy.PointGeometry,
                  arcpy.Polyline, arcpy.Multipatch,
                  arcpy.Multipoint] + list(GEOM_TYPES)
    GEOM_TYPES = tuple(GEOM_TYPES)
except ImportError:
    # warning.warn("Missing Pro will cause functionality to be limited")
    HASARCPY = False


class SpatialDataFrame(BaseSpatialPandas, DataFrame):
    """
    Pandas dataframe designed to work with geospatial information
    """
    _internal_names = ['_data', '_cacher', '_item_cache', '_cache',
                       'is_copy', '_subtyp', '_index',
                       '_default_kind', '_default_fill_value', '_metadata',
                       '__array_struct__', '__array_interface__']
    _metadata = ['sr', '_geometry_column_name', '_gis']
    _geometry_column_name = GEO_COLUMN_DEFAULT
    #----------------------------------------------------------------------
    def __init__(self, *args, **kwargs):
        """
        A Spatial Dataframe is an object to manipulate, manage and translate
        data into new forms of information for users.

        Required Parameters:
          None
        Optional:
          :data: panda's dataframe containing attribute information
          :geometry: list/array/geoseries of arcgis.geometry objects
          :sr: spatial reference of the dataframe.  This can be the factory
           code, WKT string, arcpy.SpatialReference object, or
           arcgis.SpatailReference object.
          :gis: passing a gis.GIS object set to Pro will ensure arcpy is
           installed and a full swatch of functionality is available to
           the end user.
        """
        gis = kwargs.pop('gis', arcgis.env.active_gis)
        self._gis = gis

        sr = kwargs.pop('sr', None)
        geometry = kwargs.pop('geometry', None)
        super(SpatialDataFrame, self).__init__(*args, **kwargs)

        if isinstance(sr, types.SpatialReference):
            self.sr = sr
        elif isinstance(sr, integer_types):
            self.sr = types.SpatialReference({'wkid' : sr})
        elif isinstance(sr, string_types):
            self.sr = types.SpatialReference({'wkt' : sr})
        elif hasattr(sr, 'factoryCode'):
            self.sr = types.SpatialReference({'wkid' : sr.factoryCode})
        elif hasattr(sr, 'exportToString'):
            self.sr = types.SpatialReference({'wkt' : sr.exportToString()})
        elif not sr is None:
            raise ValueError("sr (spatial reference) must be a types.SpatialReference object")
        else:
            self.sr = None
        if geometry is not None:
            # Handles case when a user passes arcpy.Point objects instead of
            # arcpy.PointGeometry.
            if isinstance(geometry, (list, tuple)) and \
               len(geometry) > 0:
                g = geometry[0]
                gtrans = []

                if HASARCPY:
                    if isinstance(g, arcpy.Point):
                        for g in geometry:
                            if isinstance(g, arcpy.Point):
                                g = arcpy.PointGeometry(g)
                            gtrans.append(types.Geometry(g))
                        geometry = gtrans
                    elif isinstance(g, arcpy.Geometry):
                        for g in geometry:
                            gtrans.append(types.Geometry(g))
                            del g
                        geometry = gtrans

            self.set_geometry(geometry, inplace=True)
        elif 'SHAPE' in self.columns:
            if isinstance(self['SHAPE'], (GeoSeries, pd.Series)):
                if all(isinstance(x, types.Geometry) \
                       for x in self[self._geometry_column_name]) == False:
                    geometry = self['SHAPE'].tolist()
                    del self['SHAPE']
                    for idx, g in enumerate(geometry):
                        if isinstance(g, types.Geometry) == False and \
                           isinstance(g, dict):
                            geometry[idx] = types.Geometry(g)
                    self.set_geometry(geometry, inplace=True)
        self._delete_index()
    #----------------------------------------------------------------------
    @property
    def _constructor(self):
        """constructor for class as per Pandas' github page"""
        return SpatialDataFrame
    #----------------------------------------------------------------------
    def __geo_interface__(self):
        """returns the object as an Feature Collection JSON string"""
        if HASARCPY:
            template = {
                "type": "FeatureCollection",
                "features": []
            }
            geom_type = self.geometry_type
            if geom_type.lower() == "point":
                geom_type = "Point"
            elif geom_type.lower() == "polyline":
                geom_type = "LineString"
            elif geom_type.lower() == "polygon":
                geom_type = "Polygon"
            df_copy = self.copy(deep=True)
            df_copy['geom_json'] = self.geometry.JSON
            df_copy['SHAPE'] = df_copy['geom_json']
            del df_copy['geom_json']
            for index, row in df_copy.iterrows():
                geom = row['SHAPE']
                del row['SHAPE']
                template['features'].append(
                    {"type" : geom_type,
                     "geometry" : pd.json.loads(geom),
                     "attributes":row}
                )
            return pd.json.dumps(template)
    @property
    def geoextent(self):
        """returns the extent of the spatial dataframe"""
        return self.series_extent
    #----------------------------------------------------------------------
    def __getstate__(self):
        meta = {k: getattr(self, k, None) for k in self._metadata}
        return dict(_data=self._data, _typ=self._typ,
                    _metadata=self._metadata, **meta)
    #----------------------------------------------------------------------
    def __setattr__(self, attr, val):
        if attr.lower() in ['geometry', 'shape', 'shape@']:
            object.__setattr__(self, attr, val)
        else:
            super(SpatialDataFrame, self).__setattr__(attr, val)
    #----------------------------------------------------------------------
    def _get_geometry(self):
        """returns the geometry series"""
        if self._geometry_column_name not in self.columns:
            raise AttributeError("Geometry Column Not Present: %s" % self._geometry_column_name)
        return self[self._geometry_column_name]
    #----------------------------------------------------------------------
    def _set_geometry(self, col):
        """sets the geometry for the panda's dataframe"""
        if isinstance(col, (GeoSeries, list, numpy.array, numpy.ndarray, Series)):
            self.set_geometry(col, inplace=True)
        else:
            raise ValueError("Must be a list, np.array, or GeoSeries")
    #----------------------------------------------------------------------
    geometry = property(fget=_get_geometry,
                        fset=_set_geometry,
                        fdel=None,
                        doc="Get/Set the geometry data for SpatialDataFrame")
    #----------------------------------------------------------------------
    def __finalize__(self, other, method=None, **kwargs):
        """propagate metadata from other to self """
        # merge operation: using metadata of the left object
        if method == 'merge':
            for name in self._metadata:
                object.__setattr__(self, name, getattr(other.left, name, None))
        # concat operation: using metadata of the first object
        elif method == 'concat':
            for name in self._metadata:
                object.__setattr__(self, name, getattr(other.objs[0], name, None))
        else:
            for name in self._metadata:
                object.__setattr__(self, name, getattr(other, name, None))
        return self
    #----------------------------------------------------------------------
    def copy(self, deep=True):
        """
        Make a copy of this SpatialDataFrame object
        Parameters:

        :deep: boolean, default True
               Make a deep copy, i.e. also copy data
        Returns:
         :copy: of SpatialDataFrame
        """
        data = self._data
        if deep:
            data = data.copy()
        return SpatialDataFrame(data, sr=self.sr).__finalize__(self)
    #----------------------------------------------------------------------
    def plot(self, *args, **kwargs):
        """ writes the spatial dataframe to a map """
        if self._gis is None:
            gis = GIS(set_active=False)
        else:
            gis = self._gis
        if self.sr:
            sr = self.sr
        else:
            sr = self.sr
        extent = None
        if HASARCPY:
            if sr:
                ext = self.geoextent
                extent = pd.json.dumps({
                    "xmin" : ext[0],
                    "ymin" : ext[1],
                    "xmax" : ext[2],
                    "ymax" : ext[3],
                    "spatialReference" : sr.factoryCode
                })
            else:
                ext = self.geoextent
                extent = pd.json.dumps({
                    "xmin" : ext[0],
                    "ymin" : ext[1],
                    "xmax" : ext[2],
                    "ymax" : ext[3]
                })
        m = gis.map()

        m.draw(self.to_featureset())
        if extent:
            m.extent = extent
        return m
    #----------------------------------------------------------------------
    @staticmethod
    def from_featureclass(filename, **kwargs):
        """
        Returns a SpatialDataFrame from a feature class.
        Inputs:
         filename: full path to the feature class
        Optional Parameters:
         sql_clause: sql clause to parse data down
         where_clause: where statement
         sr: spatial reference object

        """
        from arcgis.data.geodataset.io import from_featureclass
        return from_featureclass(filename=filename, **kwargs)
    #----------------------------------------------------------------------
    def to_featureclass(self,
                        out_location, out_name,
                        overwrite=True, skip_invalid=True):
        """converts a SpatialDataFrame to a feature class

        Parameters:
         :out_location: save location workspace
         :out_name: name of the feature class to save as
         :overwrite: boolean. True means to erase and replace value, false
          means to append
         :skip_invalids: if True, any bad rows will be ignored.
        Output:
         tuple of feature class path and list of bad rows by index number.
        """
        from arcgis.data.geodataset.io import to_featureclass
        return to_featureclass(df=self,
                               out_location=out_location,
                               out_name=out_name,
                               overwrite=overwrite, skip_invalid=skip_invalid)
    #----------------------------------------------------------------------
    def to_hdf(self, path_or_buf, key, **kwargs):
        """Write the contained data to an HDF5 file using HDFStore.

        Parameters
        ----------
        path_or_buf : the path (string) or HDFStore object
        key : string
            indentifier for the group in the store
        mode : optional, {'a', 'w', 'r+'}, default 'a'

          ``'w'``
              Write; a new file is created (an existing file with the same
              name would be deleted).
          ``'a'``
              Append; an existing file is opened for reading and writing,
              and if the file does not exist it is created.
          ``'r+'``
              It is similar to ``'a'``, but the file must already exist.
        format : 'fixed(f)|table(t)', default is 'fixed'
            fixed(f) : Fixed format
                       Fast writing/reading. Not-appendable, nor searchable
            table(t) : Table format
                       Write as a PyTables Table structure which may perform
                       worse but allow more flexible operations like searching
                       / selecting subsets of the data
        append : boolean, default False
            For Table formats, append the input data to the existing
        data_columns :  list of columns, or True, default None
            List of columns to create as indexed data columns for on-disk
            queries, or True to use all columns. By default only the axes
            of the object are indexed. See `here
            <http://pandas.pydata.org/pandas-docs/stable/io.html#query-via-data-columns>`__.

            Applicable only to format='table'.
        complevel : int, 1-9, default 0
            If a complib is specified compression will be applied
            where possible
        complib : {'zlib', 'bzip2', 'lzo', 'blosc', None}, default None
            If complevel is > 0 apply compression to objects written
            in the store wherever possible
        fletcher32 : bool, default False
            If applying compression use the fletcher32 checksum
        dropna : boolean, default False.
            If true, ALL nan rows will not be written to store.
        """

        from pandas.io import pytables
        return pytables.to_hdf(path_or_buf, key, pd.DataFrame(self), **kwargs)
    #----------------------------------------------------------------------
    @staticmethod
    def from_hdf(path_or_buf, key=None, **kwargs):
        """ read from the store, close it if we opened it

            Retrieve pandas object stored in file, optionally based on where
            criteria

            Parameters
            ----------
            path_or_buf : path (string), buffer, or path object (pathlib.Path or
                py._path.local.LocalPath) to read from

                .. versionadded:: 0.19.0 support for pathlib, py.path.

            key : group identifier in the store. Can be omitted if the HDF file
                contains a single pandas object.
            where : list of Term (or convertable) objects, optional
            start : optional, integer (defaults to None), row number to start
                selection
            stop  : optional, integer (defaults to None), row number to stop
                selection
            columns : optional, a list of columns that if not None, will limit the
                return columns
            iterator : optional, boolean, return an iterator, default False
            chunksize : optional, nrows to include in iteration, return an iterator

            Returns
            -------
            The selected object

            """
        return SpatialDataFrame(pd.read_hdf(path_or_buf=path_or_buf,
                                            key=key, **kwargs))
    #----------------------------------------------------------------------
    def to_featureset(self):
        """
        Converts a spatial dataframe to a feature set object
        """
        from arcgis.features import FeatureSet
        return FeatureSet.from_dataframe(self)
    #----------------------------------------------------------------------
    def set_geometry(self, col, drop=False, inplace=False, sr=None):
        """
        Set the SpatialDataFrame geometry using either an existing column or
        the specified input. By default yields a new object.

        The original geometry column is replaced with the input.

        Parameters:
        keys: column label or array
        drop: boolean, default True
         Delete column to be used as the new geometry
        inplace: boolean, default False
         Modify the SpatialDataFrame in place (do not create a new object)
        sr : str/result of fion.get_sr (optional)
         Coordinate system to use. If passed, overrides both DataFrame and
         col's sr. Otherwise, tries to get sr from passed col values or
         DataFrame.
        Returns:
        SpatialDataFrame
        """
        if inplace:
            frame = self
        else:
            frame = self.copy()

        if not sr:
            sr = getattr(col, 'sr', self.sr)

        to_remove = None
        geo_column_name = self._geometry_column_name
        if isinstance(col, (GeoSeries, Series, list, numpy.ndarray)):
            level = col
        elif hasattr(col, 'ndim') and col.ndim != 1:
            raise ValueError("Must pass array with one dimension only.")
        else:
            try:
                level = frame[col].values
            except KeyError:
                raise ValueError("Unknown column %s" % col)
            except:
                raise
            if drop:
                to_remove = col
                geo_column_name = self._geometry_column_name
            else:
                geo_column_name = col

        if to_remove:
            del frame[to_remove]

        if isinstance(level, GeoSeries) and level.sr != sr:
            # Avoids caching issues/sr sharing issues
            level = level.copy()
            level.sr = sr

        # Check that we are using a listlike of geometries
        if not all(isinstance(item, GEOM_TYPES) or not item for item in level):
            raise TypeError("Input geometry column must contain valid geometry objects.")
        frame[geo_column_name] = level
        frame._geometry_column_name = geo_column_name
        frame.sr = sr
        frame._delete_index()
        if not inplace:
            return frame
        self = frame
    #----------------------------------------------------------------------
    def __getitem__(self, key):
        """
        If the result is a column containing only 'geometry', return a
        GeoSeries. If it's a DataFrame with a 'geometry' column, return a
        SpatialDataFrame.
        """
        result = super(SpatialDataFrame, self).__getitem__(key)
        geo_col = self._geometry_column_name
        if isinstance(key, string_types) and key == geo_col:
            result.__class__ = GeoSeries
            result.sr = self.sr
            result._delete_index()
        elif isinstance(result, DataFrame) and geo_col in result:
            result.__class__ = SpatialDataFrame
            result.sr = self.sr
            result._geometry_column_name = geo_col
            result._delete_index()
        elif isinstance(result, DataFrame) and geo_col not in result:
            result.__class__ = DataFrame
        return result
    #----------------------------------------------------------------------
    def reproject(self, spatial_reference, transformation=None, inplace=False):
        """
        Reprojects a given dataframe into a new coordinate system.

        """
        if HASARCPY:
            if isinstance(spatial_reference, arcpy.SpatialReference):
                wkt = spatial_reference.exportToString()
                wkid = spatial_reference.factoryCode
                if wkid:
                    sr = types.SpatialReference({'wkid' : wkid})
                elif wkt:
                    sr = types.SpatialReference({'wkt': wkt})
                else:
                    sr = None
            elif isinstance(spatial_reference, int):
                sr = types.SpatialReference({'wkid' : spatial_reference})
            elif isinstance(spatial_reference, string_types):
                sr = types.SpatialReference({'wkt' : spatial_reference})
            elif isinstance(spatial_reference, types.SpatialReference):
                sr = spatial_reference
            else:
                raise ValueError("spatial_referernce must be of type: int, string, types.SpatialReference, or arcpy.SpatialReference")

            if inplace:
                df = self
            else:
                df = self.copy()
            sarcpy = sr.as_arcpy
            if sarcpy:
                geom = df.geometry.project_as(sarcpy, transformation)
                geom.sr = sr
                df.geometry = geom
                if inplace:
                    return df
            else:
                raise Exception("could not reproject the dataframe.")
            return df
    #----------------------------------------------------------------------
    def select_by_location(self, other, matches_only=True):
        """
        Selects all rows in a given SpatialDataFrame based on a given geometry

        Inputs:
         other: arcpy.Geometry object
         matches_only: boolean value, if true, only matched records will be
          returned, else a field called 'select_by_location' will be added
          to the dataframe with the results of the select by location.
        """
        if isinstance(other, Geometry):
            if self.geometry_type.lower() == 'point':
                res = self.within(other)
            else:
                res = self.overlaps(other)
            if matches_only:
                return self[res]
            else:
                self['select_by_location'] = res
        else:
            raise ValueError("Input must be a geometry")
    #----------------------------------------------------------------------
    def merge_datasets(self, other):
        """
        This operation combines two dataframes into one new DataFrame.
        If the operation is combining two SpatialDataFrames, the
        geometry_type must match.
        """
        if isinstance(other, SpatialDataFrame) and \
           other.geometry_type == self.geometry_type:
            return pd.concat(objs=[self, other], axis=0)
        elif isinstance(other, DataFrame):
            return pd.concat(objs=[self, other], axis=0)
        elif isinstance(other, Series):
            self['merged_datasets'] = other
        elif isinstance(other, SpatialDataFrame) and \
             other.geometry_type != self.geometry_type:
            raise ValueError("Spatial DataFrames must have the same geometry type.")
        else:
            raise ValueError("Merge datasets cannot merge types %s" % type(other))
    #----------------------------------------------------------------------
    def erase(self, other, inplace=False):
        """
        Erases
        """
        if inplace:
            df = self
        else:
            df = self.copy()
        if isinstance(other, Geometry):
            df.geometry = self.geometry.symmetricDifference(other)
            return df
        else:
            raise ValueError("Input must be of type arcpy.Geometry, not %s" % type(other))

###########################################################################
def _dataframe_set_geometry(self, col, drop=False, inplace=False, sr=None):
    if inplace:
        raise ValueError("Can't do inplace setting when converting from"
                         " DataFrame to SpatialDataFrame")
    gf = SpatialDataFrame(self)
    # this will copy so that BlockManager gets copied
    return gf.set_geometry(col, drop=drop, inplace=False, sr=sr)

if PY3:
    DataFrame.set_geometry = _dataframe_set_geometry
else:
    import types
    DataFrame.set_geometry = types.MethodType(_dataframe_set_geometry, None,
                                              DataFrame)